from django.contrib import admin
from .models import ArticlePost
admin.site.register(ArticlePost)
# Register your models here.
